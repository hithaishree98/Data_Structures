public class HW1_ds{
	public static void main (String [] args){
		int maxrange;
		int n=1;
		int i;
		int primecount = 0;
		int compositeflag =0;
		for(maxrange=0;maxrange<=100000;maxrange=maxrange+10000){
			primecount=0;
			long startTime = System.nanoTime();
			for(n=2;n<maxrange;n++){
				compositeflag=0;
				for(i=2;i<n;i++){
					if((n%i)==0){
						compositeflag=1;
					//System.out.println("Composite ="+n);
					}
					
				}

				if(compositeflag==0){
					//System.out.println("Prime ="+n);
					primecount++;
				}
							
			}
			long endTime = System.nanoTime();
			System.out.println("Primecount ="+primecount);
		    System.out.println("Step is on "+maxrange);
			
			long TimeTaken = endTime - startTime;
			System.out.println("TimeTaken = "+(TimeTaken/1000000000));
	    }
		
	}
}